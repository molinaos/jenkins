adduser jenkins
apt-get update
apt-get install openjdk-8-jdk wget gnupg git vim
mkdir /jenkins
chwon -R jenkins:jenkins /jenkins
# sudo su jenkins
# vim /home/jenkins/.ssh/authorized_keys

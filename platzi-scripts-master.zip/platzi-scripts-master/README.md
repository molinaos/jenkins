# Platzi Scripts

Dummy tests are in `jenkins-tests`

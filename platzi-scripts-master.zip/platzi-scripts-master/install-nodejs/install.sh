apt-get install curl
curl -sL https://deb.nodesource.com/setup_11.x | bash -
apt-get install -y nodejs
